############extra imports selenium###########

from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By







import json
import openpyxl 
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import pandas as pd
import re
import time
from datetime import datetime,timedelta,date
from bs4 import BeautifulSoup
import numpy as np
import html2text
import os, glob
import sys
# import send_email
#DRIVER INSTALLATIONS
driver = webdriver.Firefox()
#MAXIMIZE THE CHROME
driver.maximize_window()
today = date.today()
try:
    time.sleep(2)
    ds_usa_url = 'https://www.linkedin.com/login'
    driver.get(ds_usa_url)
    time.sleep(2)
    #LOGIN CREDENTIAL
    user = WebDriverWait(driver, 10).until(EC.visibility_of_element_located
        ((By.ID, 'username')))
    user.send_keys('amitkanherkar.aress@gmail.com')

    # User password
    pwd = WebDriverWait(driver, 10).until(EC.visibility_of_element_located
        ((By.ID, 'password')))
    pwd.send_keys('Manish123!')

    WebDriverWait(driver, 10).until(EC.visibility_of_element_located((By.XPATH, '//*[@id="organic-div"]/form/div[3]/button'))).click()
except Exception as e:
    print('Error in login process', e)

def post_extraction(dom):
    try:
        print("*"*100)
        
        dom = 'generative ai'
        # driver.implicitly_wait(10)
        time.sleep(5)
        print("domain name is", dom)
        driver.get('https://www.linkedin.com/feed/')
        time.sleep(5)
        driver.find_element(By.XPATH,"//input[@aria-label='Search']").clear()
        time.sleep(5)
        driver.find_element(By.XPATH,"//input[@aria-label='Search']").send_keys(dom)
        time.sleep(5)
        driver.find_element(By.XPATH,"//input[@aria-label='Search']").send_keys(Keys.ENTER )
        
        ##############################FILTER SELECTIONS#########################
        #POST
        time.sleep(5)
        post = driver.find_element(By.XPATH,'//div[@class = "authentication-outlet"]')
        
        time.sleep(5)
        post.find_element(By.XPATH,"//*[text() = 'Posts']").click()
        # post.find_element_by_xpath("//button[@aria-label= 'Posts']").click()
        time.sleep(5)
        #All Filters BOX
        time.sleep(5)
        filters = driver.find_element(By.XPATH,'//div[@class = "display-flex align-items-center"]')
        filters.find_element(By.XPATH,"//*[text() = 'All filters']").click()
        time.sleep(5)
        #PAST WEEK
        filter_box = driver.find_element(By.XPATH,'//div[@class = "artdeco-modal artdeco-modal--layer-default justify-space-between search-reusables__side-panel search-reusables__side-panel--open"]')
    
        filter_box.find_element(By.XPATH,"//*[text() = 'Past week']").click()
        time.sleep(5)
        #LATEST SELECTION POST
        filter_box.find_element(By.XPATH,"//*[text() = 'Latest']").click()
        time.sleep(5)
        driver.find_element(By.XPATH,"//button[@aria-label= 'Apply current filters to show results']").click()
        #####################################SCROLLER
        for i in range(0,60):
            time.sleep(2)
            driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
        driver.execute_script("window.scrollTo(0, 0);")
        ######################################BS4 Capturing
        #BS4 panel
        source  = BeautifulSoup(driver.page_source)
        #Capture the content box
        post_link_list= []
        
        post_list = driver.find_elements(By.XPATH,'//div[@class= "ember-view  occludable-update "]')
        
        
        
        # search_res = source.findAll('div',{'class':'ember-view  occludable-update'})
        
        # search_res = driver.find_elements(By.XPATH,"//ul[contains(@class, 'artdeco-card mb2')]//a[contains(@class, 'reusable-search__entity-result-list list-style-none')]")
    
        
        
        description_temp_name_list = [];title_name_list =[];time_list =[];link_list=[];temp_link=[]
        all_mailto_links = [];hashtag_links=[];normal_link_list =[];mail_to_links=[];time_stamp_list=[]
        
        attempt=1
        print("the length of post is", len(post_list))
        for index, post in enumerate(post_list):
        # Get the HTML of the post
            
            
            
            ##################################updated##################################
            post_html = post.get_attribute('outerHTML')
            mail_to_links = re.findall(r'(?<=href="mailto:)[^"\s]*', post_html)
            all_mailto_links.append(mail_to_links)
            #####################################updated################################
            
            
            # mail_to = re.findall(r'(?<=href=\"mailto\:)[^\"\s]*', str(search_res[i]))
            # if mail_to !=[]:
            #     mail_to_list.append(mail_to[0])
            # else:
            #     mail_to_list.append(np.nan)
            
            
            ###################################updated###################################
            app_aware_links = post.find_elements(By.CLASS_NAME, "app-aware-link")
            unique_links = set()
            for link in app_aware_links:
                href = link.get_attribute("href")
                if href and "UpdateUrns" not in href and "hashtag" not in href and "mailto" not in href:  # Ensure the href attribute exists and does not contain 'UpdateUrns' or 'hashtag'
                    unique_links.add(href)
            
            hashtag_links.append(list(unique_links))
            
            
            
            # hashtag_links = re.findall(r'(?<=href=")[^"\s]*hashtag[^"\s]*', post_html)        # Join the links with commas and store in hastag_list
            # hastag_list.append(','.join(hashtag_links) if hashtag_links else np.nan)
            # ###################################updated###################################
    
            
            
            
            # hastag_link = re.findall(r"(?<=href=\")[^\"^\>^\#]*(?=\"\>\#)", str(search_res[i]))
            # if hastag_link !=[]:
            #     hastag_list.append(hastag_link)
            # else:
            #     hastag_list.append(np.nan)
                
            ##################################updated#####################################
            post_links = []
            # Find all anchor tags within the current post element
            anchor_tags = post.find_elements(By.TAG_NAME, "a")
            # Extract and store the href attribute of each anchor tag
            first_anchor = anchor_tags[0]
            for anchor in anchor_tags:
                href = first_anchor.get_attribute("href")
                post_links.append(href)
            # Add the list of links for this post to the main list
            normal_link_list.append(post_links[0])
            ##########################updated#############################################
            
            # normal_link = re.findall(r"(?<=href=\")[^\"^\>^\#]*(?=\"\starget)", str(search_res[i]))
            # if normal_link !=[]:
            #     normal_link_list.append(normal_link)
            # else:
            #     normal_link_list.append(np.nan)
            ##########################updated#############################################        
            title_name_var = re.findall(r'<span dir="ltr">.*?>(.*?)<\/span>', post_html, re.DOTALL)
            # Clean up the results
            title_name_var = [re.sub(r'<.*?>', '', name).strip() for name in title_name_var]
        
            if title_name_var!=[]:
                title_name_list.append(title_name_var[0])
            else:
                title_name_list.append(np.nan)
            ##########################updated#############################################
    
            # title_name_var = re.findall(r'(?<=\<span dir=\"ltr\"\>)(.*)', str(search_res[i]))
            # if title_name_var!=[]:
            #     title_name_var_name = title_name_var[0].split('</span>')[0]
            #     title_name_list.append(title_name_var_name.strip())
            # else:
            #     title_name_list.append(np.nan)
            
            ##########################updated#############################################
            post_text = post.text
            post_parts = post_text.split('Follow')
            
            if len(post_parts) > 1:
                description_part = post_parts[1]
        
                # Remove 'Like', 'Comment', 'Send', and any remaining unwanted parts
                description_part = re.split(r'Like|Comment|Send', description_part, maxsplit=1)[0].strip()
                description_part = re.sub(r'\s+', ' ', description_part).strip()
                
                # Remove emojis from description
                description_part = re.sub(r'[\U0001F600-\U0001F64F\U0001F300-\U0001F5FF\U0001F680-\U0001F6FF\U0001F700-\U0001F77F\U0001F780-\U0001F7FF\U0001F800-\U0001F8FF\U0001F900-\U0001F9FF\U0001FA00-\U0001FA6F\U0001FA70-\U0001FAFF\U00002702-\U000027B0\U000024C2-\U0001F251]+', '', description_part)
        
                # Append cleaned description
                description_temp_name_list.append(description_part)
            else:
                description_temp_name_list.append(np.nan)
                
            ##########################updated#############################################
    
            
            # description_temp = re.findall(r'(?<=\<span dir=\"ltr\"\>)(.*)', str(search_res[i]))
            # try:
            #     description_temp_name = description_temp[1].split('</span>')[0]
            #     description_temp_name = html2text.html2text(description_temp_name)
            #     description_temp_name_list.append(description_temp_name.strip())
            # except:
            #     description_temp_name_list.append(np.nan)
            
            
            
            
            # time_stamp_element = re.findall(r'(?<=\<span aria\-hidden\=\"true\"\>)([\s\S]*)', str(search_res[i]))
            
            ##########################updated#############################################
    
            time_stamp_element = post.find_element(By.XPATH, './/a[@class="app-aware-link  update-components-actor__sub-description-link"]')        
            ##########################updated#############################################
            
           
            time_temp = time_stamp_element.text
            time_stamp_list.append(time_temp)
            print(time_temp)
            if time_temp !=[]:
                if 'h' in time_temp or 'm' in time_temp or 's' in time_temp or 'n' in time_temp:
                    time_stamp_var = today.strftime("%d/%m/%Y")
                    time_list.append(time_stamp_var)
                elif 'd' in time_temp or 'w' in time_temp:
                    time_diff = eval(time_temp.replace('d',''))
                    time_stamp_var = today - timedelta(days = time_diff)
                    time_list.append(time_stamp_var.strftime("%d/%m/%Y"))
                else:
                    time_list.append(np.nan)
            else:
                time_list.append(np.nan)
    
            # print(description_temp_name)
    
            #Links_list_Post
            try:
                ccc= post_list[index].get_attribute('innerHTML')
                ddd= re.findall(r'(?<=id\=\"ember)(.*)(?=\" class\=\"artdeco-dropdown)',str(ccc))
                time.sleep(2)
                #we have to apply regular expression
                driver.find_element(By.XPATH, f"//div[@id='ember{ddd[0]}' and @class='artdeco-dropdown artdeco-dropdown--placement-bottom artdeco-dropdown--justification-right ember-view']").click()
                time.sleep(2)
                post_list[i].find_element(By.XPATH,"//*[text() = 'Copy link to post']").click()
                time.sleep(2)
                sour1  = BeautifulSoup(driver.page_source)
                view_post= sour1.find_all('p',{'class':'artdeco-toast-item__message'})
                time.sleep(2)
                v_post = re.findall(r'(?<=href=")(.*)(?=")', str(view_post))
                
                # print(v_post[0])
                post_link_list.append(v_post[0])
                print('v_post:',v_post[0])
                # cancel= driver.find_element(By.XPATH,'//li-icon[@type="cancel-icon"]').click()
                time.sleep(2)
                
            except Exception as p:
                # attempt=+1
                print("post link exception as ----->",p)
    
                post_link_list.append(np.nan)
    except Exception as k:
        print('Exception in scrapping function',k)
        pass
            
    print("length of post link is",len(post_link_list))
    df = pd.DataFrame ({"Post Name": dom.title(),
                        "Title Name":title_name_list,
                       "Description":description_temp_name_list,
                       'Email List': all_mailto_links,
                       "PostLinks":post_link_list,
                       "Date":time_list,
                       "Hastag List":hashtag_links,
                       "Link List": normal_link_list
                       })
    df = df.dropna(subset=["PostLinks"])
    locations_list = []
    for i in range(len(df)):
            
        try:
            print(i)
            driver.get(df.PostLinks.iloc[i])
            time.sleep(5)
            driver.find_element(By.XPATH, f'/html/body/div[5]/div[3]/div/div/div[2]/div/div/main/div/section/div/div/div/div/div[2]/div/div[1]/div[1]/div/div/a[1]/span[1]/span[1]').click()
            time.sleep(5)
            pros=BeautifulSoup(driver.page_source)
        
            temp_loc= pros.findAll('span',{'class':'text-body-small inline t-black--light break-words'})[0].text
            # org-top-card-summary-info-list t-14 t-black--light
            temp_loc = temp_loc.strip()
            locations_data = temp_loc.split(',')[-1].strip()
            print(locations_data)
            locations_list.append(locations_data.strip())
        except:
            try:
                  temp_loc = driver.find_element(By.XPATH,'//div[contains(@class, "inline-block")]/div[contains(@class, "org-top-card-summary-info-list__info-item")]')
                  temp_loc_2 = temp_loc.text
                  print(temp_loc_2)
        #         temp3 = temp_loc_2.split('"inline-block">')[-1]
        #         locations_data = html2text.html2text(temp3).split('\n')[0].split(',')[-1]
        #         if 'followers'in locations_data:
        #             locations_list.append(np.nan)
        #         else:
        #             print(locations_data)

                  locations_list.append(temp_loc_2)
        #             # print("-"*30)
            except Exception as e:
                print("Error in locations is ",e)
                locations_list.append(np.nan)
                pass
    df["Locations"] = locations_list
    df = df[['Post Name', 'Title Name', 'Description', 'Email List', 'PostLinks','Locations' ,'Date','Hastag List', 'Link List' ]]
           
    df = df.dropna(subset=["Locations"])
    save_file_name =  'Linkedin_Post_scrapping'+today.strftime("%d_%m_%Y")+'.csv'
    df.to_csv(save_file_name)
    
    print('length of dataFrame is',len(df))
  
    return df




def dom_read():
    domain_name_list = []
    with open('domain.txt') as f:
        for dom in f:
            if dom:
                dom = dom[:-1].replace(',','')
                domain_name_list.append(dom.strip())
    all_dd = pd.DataFrame()
    # domain_name_list =['Tableau Developer']
    for i in domain_name_list:
        data_frame = post_extraction(i.lower())
        all_dd = pd.concat([all_dd, data_frame], ignore_index=True)
        all_dd.to_csv('post_final.csv')
    curr = os.getcwd()
    
     
    dir_data = curr+'\\Linked_in_post_output'
    filelist = glob.glob(os.path.join(dir_data, "*"))
    for f in filelist:
        os.remove(f)
    if not os.path.exists(curr+'\\Linked_in_post_output'):
        # os.chdir(curr)
        os.makedirs(curr+'\\Linked_in_post_output')
    save_dir = curr+'\\Linked_in_post_output'
    os.chdir(save_dir)
    save_file_name =  'Linkedin_Post_'+today.strftime("%d_%m_%Y")+'.csv'
    all_dd.to_csv(save_file_name,index=False)
    # filename = save_dir+'\\'+save_file_name
    os.chdir(curr)
    sender_list = []
    with open('sender_list.txt') as f:
        for s_l in f:
            if s_l:
                s_l = s_l.replace(',','')
                # sender_list = 
                sender_list.append(s_l.strip())
    receiver_email=''
    receiver_email = ','.join(sender_list)
    #=======================MAIL_CONTENT======
    dom_str = ""
    for ind,i in enumerate(domain_name_list):
        dom_str +=str(ind+1)+". "+i+"\n"
    

    mail_content = f"""Hi, \nPlease find the attachment.\n\nAttached excel data contains following Technologies:\n{dom_str.title()}
    \n\n
    Thanks and Regards
    Data Analytics Team
    """
    mail_send = send_email.send_the_data(receiver_email,save_dir,save_file_name,curr,mail_content)
    # send_email.system_exit(driver)
    

while True:
    try:
        dom_read()
        driver.close()
        break
    except Exception as e:
        print("Hey we have an error as-->\n", e)
        pass

sys.exit()

# driver.close()    
# df.to_csv("linkdin_post.csv",index=False) 
# import send_email   

"""   
description_html = source.findAll("div",{'class':"feed-shared-update-v2__description-wrapper"})
all_span= source.find_all('div',class_='feed-shared-actor__meta relative')
# title_name_source = source.findAll("span",{'class':"feed-shared-actor__title"})
# time_source = source.findAll("span",{'class':"feed-shared-actor__sub-description t-12 t-normalt-black--light"})

feed-shared-update-v2__description-wrapper

# designation_list_source = source.findAll("span",{'class':"feed-shared-actor__description t-12 t-normalt-black--light"}) 

#list creation
title_name_list = []
description_list = []
link_list = []
time_list = []
temp_link=[]
# designation_list = []
today = date.today()
    
#Extracting data 
#For title name
 # \<li\-icon aria\-hidden

#TITLE 
# description_html= source.findAll("span",{'dir':"ltr"})
########################################################################
#Need to work on it
title_name_list = []
search_all= source.findAll("div",{'class':"search-results-container"})
# for i in search_all:
# var = 
title_name_var = re.findall(r'(?<=<span dir=\"ltr\"\>)(.*)',str(search_all))
print(title_name_var)


# if title_name_var ==[]:
#     title_name_list.append(np.nan)
# else:
#     title_name_list.append(title_name_var[0].split('</span>')[0])
###########################################################################
        
for i in all_span:
    var = str(i)
    title_name_var = re.findall(r'(?<=<span dir=\"ltr\"\>)(.*)',var)
    if title_name_var ==[]:
        title_name_list.append(np.nan)
    else:
        title_name_list.append(title_name_var[0].split('</span>')[0])
        
        
        
# Description


#for link 
for i in description_html:
    print(i.text)
    
    aa = i.find_all('a')
    if aa==[]:
        link_list.append(np.nan)
        temp_link.append(np.nan)
        pass
        
    else:
        # print(aa.text)
        temp =[]
        temp_link.append(aa)
        for x in aa:
            # print(x)
            if "hashtag" not in str(x):
                # print(x)
                link_list.append(x.get('href'))
            # link_list.append(temp)
    description_list.append(i.text.strip()) 
    
# Date
for i in all_span:
    # print(i.text.strip())
    temp_time = re.findall(r'(?<=<span aria\-hidden\=\"true\"\>)([\s\S]*)(?= \• )',str(i))[0]
    temp_time = temp_time.replace(' • Edited','')
    if 'h' in temp_time:
        print('we consider as a same day',temp_time, today)


df = pd.DataFrame ({"Title_Name":title_name_list,
                   "Description":description_list,
                   "Link":link_list,
                   "time":temp_time})    


for i in range(0,10):
    time.sleep(2)
    driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
driver.execute_script("window.scrollTo(0, 0);")


post=driver.find_element_by_class_name("search-results-container")
driver.find_element_by_xpath("//button[@class='feed-shared-inline-show-more-text__see-more-less-toggle see-more t-14 t-black--light t-normal hoverable-link-text']").text


# c=[]
# for i in post:
#     c.append(i.text)
# print(c)
# print()
# print(len(c))

# col=["post"]
# df=pd.DataFrame({"Post":post})
# df.head()
# df.to_csv("linkdin_jobs.csv")

see_more_toggle = source.findAll("button",{'class':"feed-shared-inline-show-more-text__see-more-less-toggle see-more t-14 t-black--light t-normal hoverable-link-text"})
# #Sort by panel#################################################
# sort_data = post.text.split("\n")[3]
# if sort_data == 'Sort by':
#     post.find_element_by_xpath("//button[@aria-label = 'Sort by filter. Clicking this button displays all Sort by filter options.']").click()
# sort_dropdown = driver.find_element_by_id('hoverable-outlet-sort-by-filter-value')
# time.sleep(5)

# select_one_top_match = sort_dropdown.text.split("\n")[1]
#sort_dropdown.find_element_by_xpath("//*[text()='Top match']").click()
# sort_dropdown.find_element_by_xpath("//*[text()='Latest']").click()
#sort_dropdown.find_element_by_xpath("//*[@id='ember758']").click()
# post.find_element_by_xpath("//*[text() = '…see more']").text
# driver.find_element_by_xpath("/html/body/div[6]/div[3]/div/div[2]/section/div/nav/div/ul/li[3]/div/div/div/div[1]/div/form/fieldset/div[2]/button[2]/span").text
# driver.find_element_by_class_name("artdeco-button__text").text
#######################################
# material_data = source.findAll("div",{'class':"search-results-container"})
#################################################
############

"""