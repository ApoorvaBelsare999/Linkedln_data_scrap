import time
print("Hello word")
time.sleep(10)